#!/sbin/sh
# Universal Flasher tool by JRsoft & Intronauta
# More info http://www.htcmania.com/showthread.php?t=258333
# based in the "VillainTheme system" tool by VillainTeam. More info etc, head to www.villainrom.co.uk
#
# This file is part of Universal Flasher Template.

if [ ! -d /Utmp ]; then
  mkdir /Utmp
fi


