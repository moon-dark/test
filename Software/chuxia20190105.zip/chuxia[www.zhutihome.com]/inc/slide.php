<div id="slideBox" class="slide w750">
	<div class="bd">
		<ul>
			<li>
				<a href="<?php echo get_op('slide_url1'); ?>" target="_blank"><img src="<?php echo get_op('slide_img1'); ?>"/></a>
				<a class="tit" href="<?php echo get_op('slide_url1'); ?>" target="_blank"><?php echo get_op('slide_tit1'); ?></a>
			</li>
			<li>
				<a href="<?php echo get_op('slide_url2'); ?>" target="_blank"><img src="<?php echo get_op('slide_img2'); ?>"/></a>
				<a class="tit" href="<?php echo get_op('slide_url2'); ?>" target="_blank"><?php echo get_op('slide_tit2'); ?></a>
			</li>
			<li>
				<a href="<?php echo get_op('slide_url3'); ?>" target="_blank"><img src="<?php echo get_op('slide_img3'); ?>"/></a>
				<a class="tit" href="<?php echo get_op('slide_url3'); ?>" target="_blank"><?php echo get_op('slide_tit3'); ?></a>
			</li>
			<li>
				<a href="<?php echo get_op('slide_url4'); ?>" target="_blank"><img src="<?php echo get_op('slide_img4'); ?>"/></a>
				<a class="tit" href="<?php echo get_op('slide_url4'); ?>" target="_blank"><?php echo get_op('slide_tit4'); ?></a>
			</li>
		</ul>
	</div>
	<div class="hd"><ul></ul></div>
</div>